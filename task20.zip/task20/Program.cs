﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task20
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите радиус R=");
            double R = Convert.ToDouble(Console.ReadLine());
            MyDeligate myDeligate = new MyDeligate(Length);
            Console.WriteLine($"Длинна окружности с радиусом R= {R} равна: {myDeligate?.Invoke(R)}");
            myDeligate += Area;
            Console.WriteLine($"Площадь круга с радиусом R= {R} равна: {myDeligate?.Invoke(R)}");
            myDeligate += Volume;
            Console.WriteLine($"Обьем шара с радиусом R= {R} равен: {myDeligate?.Invoke(R)}");
            Console.ReadKey();
        }
        delegate double MyDeligate(double R);
        static double Length(double R)
        {
            return 2 * Math.PI * R;
        }
        static double Area(double R)
        {
            return Math.PI * Math.Pow(R, 2);
        }
        static double Volume(double R)
        {
            return 4 / 3 * Math.PI * Math.Pow(R, 3);
        }
    }
}
